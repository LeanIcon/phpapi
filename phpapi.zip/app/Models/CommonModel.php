<?php 

namespace App\Models;

interface CommonModel {
    
}